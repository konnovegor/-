﻿namespace Lab_rabota_1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tbx = new System.Windows.Forms.TextBox();
            this.tby = new System.Windows.Forms.TextBox();
            this.tbz = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tba = new System.Windows.Forms.TextBox();
            this.tbb = new System.Windows.Forms.TextBox();
            this.tbg = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.tbxy = new System.Windows.Forms.TextBox();
            this.tbzx = new System.Windows.Forms.TextBox();
            this.tbxz = new System.Windows.Forms.TextBox();
            this.tbyx = new System.Windows.Forms.TextBox();
            this.tbzy = new System.Windows.Forms.TextBox();
            this.tbyz = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textbxx = new System.Windows.Forms.TextBox();
            this.textbxz = new System.Windows.Forms.TextBox();
            this.textbxy = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(401, 465);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(430, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Масштаб";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Масштаб_Click);
            // 
            // tbx
            // 
            this.tbx.Location = new System.Drawing.Point(430, 46);
            this.tbx.Name = "tbx";
            this.tbx.Size = new System.Drawing.Size(100, 20);
            this.tbx.TabIndex = 2;
            // 
            // tby
            // 
            this.tby.Location = new System.Drawing.Point(536, 46);
            this.tby.Name = "tby";
            this.tby.Size = new System.Drawing.Size(100, 20);
            this.tby.TabIndex = 3;
            // 
            // tbz
            // 
            this.tbz.Location = new System.Drawing.Point(642, 46);
            this.tbz.Name = "tbz";
            this.tbz.Size = new System.Drawing.Size(100, 20);
            this.tbz.TabIndex = 4;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(430, 77);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 5;
            this.button3.Text = "Поворот";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Поворот_Click);
            // 
            // tba
            // 
            this.tba.Location = new System.Drawing.Point(430, 106);
            this.tba.Name = "tba";
            this.tba.Size = new System.Drawing.Size(100, 20);
            this.tba.TabIndex = 6;
            // 
            // tbb
            // 
            this.tbb.Location = new System.Drawing.Point(536, 106);
            this.tbb.Name = "tbb";
            this.tbb.Size = new System.Drawing.Size(100, 20);
            this.tbb.TabIndex = 7;
            // 
            // tbg
            // 
            this.tbg.Location = new System.Drawing.Point(642, 106);
            this.tbg.Name = "tbg";
            this.tbg.Size = new System.Drawing.Size(100, 20);
            this.tbg.TabIndex = 8;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(430, 139);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 9;
            this.button4.Text = "Сдвиг";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Сдвиг_Click);
            // 
            // tbxy
            // 
            this.tbxy.Location = new System.Drawing.Point(430, 168);
            this.tbxy.Name = "tbxy";
            this.tbxy.Size = new System.Drawing.Size(100, 20);
            this.tbxy.TabIndex = 10;
            // 
            // tbzx
            // 
            this.tbzx.Location = new System.Drawing.Point(430, 194);
            this.tbzx.Name = "tbzx";
            this.tbzx.Size = new System.Drawing.Size(100, 20);
            this.tbzx.TabIndex = 11;
            // 
            // tbxz
            // 
            this.tbxz.Location = new System.Drawing.Point(642, 168);
            this.tbxz.Name = "tbxz";
            this.tbxz.Size = new System.Drawing.Size(100, 20);
            this.tbxz.TabIndex = 12;
            // 
            // tbyx
            // 
            this.tbyx.Location = new System.Drawing.Point(536, 168);
            this.tbyx.Name = "tbyx";
            this.tbyx.Size = new System.Drawing.Size(100, 20);
            this.tbyx.TabIndex = 13;
            // 
            // tbzy
            // 
            this.tbzy.Location = new System.Drawing.Point(642, 194);
            this.tbzy.Name = "tbzy";
            this.tbzy.Size = new System.Drawing.Size(100, 20);
            this.tbzy.TabIndex = 14;
            // 
            // tbyz
            // 
            this.tbyz.Location = new System.Drawing.Point(536, 194);
            this.tbyz.Name = "tbyz";
            this.tbyz.Size = new System.Drawing.Size(100, 20);
            this.tbyz.TabIndex = 15;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(430, 236);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 16;
            this.button5.Text = "Перенос";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Перенос_Click);
            // 
            // textbxx
            // 
            this.textbxx.Location = new System.Drawing.Point(430, 265);
            this.textbxx.Name = "textbxx";
            this.textbxx.Size = new System.Drawing.Size(100, 20);
            this.textbxx.TabIndex = 17;
            // 
            // textbxz
            // 
            this.textbxz.Location = new System.Drawing.Point(642, 265);
            this.textbxz.Name = "textbxz";
            this.textbxz.Size = new System.Drawing.Size(100, 20);
            this.textbxz.TabIndex = 18;
            // 
            // textbxy
            // 
            this.textbxy.Location = new System.Drawing.Point(536, 265);
            this.textbxy.Name = "textbxy";
            this.textbxy.Size = new System.Drawing.Size(100, 20);
            this.textbxy.TabIndex = 19;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(560, 332);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 20;
            this.button6.Text = "Вмещение";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Вмещение_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(754, 489);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.textbxy);
            this.Controls.Add(this.textbxz);
            this.Controls.Add(this.textbxx);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.tbyz);
            this.Controls.Add(this.tbzy);
            this.Controls.Add(this.tbyx);
            this.Controls.Add(this.tbxz);
            this.Controls.Add(this.tbzx);
            this.Controls.Add(this.tbxy);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.tbg);
            this.Controls.Add(this.tbb);
            this.Controls.Add(this.tba);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tbz);
            this.Controls.Add(this.tby);
            this.Controls.Add(this.tbx);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picture;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tbx;
        private System.Windows.Forms.TextBox tby;
        private System.Windows.Forms.TextBox tbz;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox tba;
        private System.Windows.Forms.TextBox tbb;
        private System.Windows.Forms.TextBox tbg;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox tbxy;
        private System.Windows.Forms.TextBox tbzx;
        private System.Windows.Forms.TextBox tbxz;
        private System.Windows.Forms.TextBox tbyx;
        private System.Windows.Forms.TextBox tbzy;
        private System.Windows.Forms.TextBox tbyz;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textbxx;
        private System.Windows.Forms.TextBox textbxz;
        private System.Windows.Forms.TextBox textbxy;
        private System.Windows.Forms.Button button6;
    }
}

